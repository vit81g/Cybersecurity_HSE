#!/bin/bash
python3 baseline.py
