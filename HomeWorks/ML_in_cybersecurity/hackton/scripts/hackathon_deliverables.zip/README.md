# Hackathon Deliverables — Baseline Solution

**Состав:**
- `baseline.py` — быстрый baseline (извлекает табличные признаки из URL и обучает LogisticRegression)
- `requirements.txt` — минимальные зависимости
- `run.sh` — скрипт запуска
- `README.md` — инструкция

**Запуск:**
```bash
pip install -r requirements.txt
python3 baseline.py
```
**Входные файлы:** `train.csv`, `test.csv`, `sample_submit.csv`  
**Выход:** `submission_baseline.csv` (готов для загрузки на платформу)
