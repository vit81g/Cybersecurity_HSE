""" Pure Python GOST cryptographic functions library.

pygost is free software: see the file COPYING for copying conditions.
"""
